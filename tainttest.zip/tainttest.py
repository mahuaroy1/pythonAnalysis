import os

def tainted_function():
    return input("Enter a command: ")

user_list = [tainted_function(), "safe_value"]
os.system(user_list[0])  # Unsafe: tainted list element

user_dict = {"cmd": tainted_function()}
os.system(user_dict["cmd"])  # Unsafe: tainted dictionary value

def safe_function():
    return "safe_value"

safe_result = safe_function()
